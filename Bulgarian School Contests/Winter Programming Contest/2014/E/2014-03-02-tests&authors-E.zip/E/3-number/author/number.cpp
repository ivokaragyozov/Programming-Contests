//Task: number
//�uthor: Zornica Dzhenkova

#include <iostream>
using namespace std;
int main()
{ int a,b,i,j,n,c,br=0;
  long long s=0;  
  
  cin>>n>>c;  
	 for(i=100;i<=999;i++)
	 for(j=100;j<=999;j++)
	 {a=1000*i+j; 
		 if((a>=n)&&(a<=c))
		 {
		  b=i+j; if (a%b==0) {br++;s=s+a;}
	     }
	 }
	cout<<br<<" "<<s<<endl; 
}
