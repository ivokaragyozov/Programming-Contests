//Task: busstop
//Author: Bistra Taneva

#include<iostream>
using namespace std;
int main()
{
    long long i,n,a[101],TemPr=1,br=0,s=0,s1=0;
    cin>>n;
    for(i=0;i<n-1;i++)
        cin>>a[i];
    for(i=0;i<n-2;i++)
    {
        if(a[i]<a[i+1]){TemPr++;s1+=a[i];}
        else
        {
            s1+=a[i];
            if(TemPr>br){br=TemPr;s=s1;}
            TemPr=1;
            s1=0;
        }
    }
    if(TemPr!=1)
        if(TemPr>br){br=TemPr;s=a[i]+s1;}
    cout<<br<<endl;
    for(i=s/2;i>=1;i--)
        if(s%i==0)
        {
            cout<<i<<endl;
            break;
        }
    return 0;
}
