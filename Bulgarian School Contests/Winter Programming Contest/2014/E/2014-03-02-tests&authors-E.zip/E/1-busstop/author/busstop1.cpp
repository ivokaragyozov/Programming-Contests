//Task: busstop
//Author: Kinka Kirilova-Lupanova

#include<iostream>
using namespace std;
int main()
{
    long long s=0,s1=0;
    long long i,n,a,b,TemPr=1,br=0;
    cin>>n;
    cin>>a;
    for(i=0;i<n-2;i++)
    {cin>>b;
        if(a<b){TemPr++;s1+=a;}
        else
        {
            s1+=a;
            if(TemPr>br){br=TemPr;s=s1;}
            TemPr=1;
            s1=0;
        }
     a=b;  
    }
    if(TemPr!=1)
        if(TemPr>br){br=TemPr;s=b+s1;}
    cout<<br<<endl;
    for(i=s/2;i>=1;i--)
        if(s%i==0)
        {
            cout<<i<<endl;
            break;
        }    
    return 0;
}
