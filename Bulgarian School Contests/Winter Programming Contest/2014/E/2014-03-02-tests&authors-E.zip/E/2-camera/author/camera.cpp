//Task:camera
//Author:Plamenka Hristova
#include <iostream>
#include <ctype.h>

using namespace std;

int main()
{
    char buf1, buf2;    // Буфер - вход
    int  stime, ftime;  // Време на започване / приключване на запис
    int  num;           // Брой превозни средства или 1
    int  carType;       // Тип на превозното средство: 1 - лека кола; 2 - камион;
    int  Sl, Sh;        // Суматори - леки, камиони
    bool skip = false;  // Флаг - ако е true следващият символ е вече консумиран и се пропуска

    // Пресмятане на продължителността на записа
    cin >> buf1;
    stime = (buf1-'0')*10*60;
    cin >> buf1;
    stime += (buf1-'0')*60;
    cin >> buf1;
    stime += (buf1-'0')*10;
    cin >> buf1;
    stime += buf1-'0';

    cin >> buf1;
    ftime = (buf1-'0')*10*60;
    cin >> buf1;
    ftime += (buf1-'0')*60;
    cin >> buf1;
    ftime += (buf1-'0')*10;
    cin >> buf1;
    ftime += buf1-'0';
    if(ftime <= stime)ftime += 24*60;
    stime = ftime - stime;
    ftime = stime % 60;
    stime /= 60;
    cout<<stime<<" "<<ftime<<endl; // Печат - продължителност

    Sl = Sh = 0;
    cin>> buf1;
    if(buf1!='#')
    do{
       cin>> buf2;
       if(skip)  //Прескача следващ символ след двубуквена група - Gr или 12
         {
          buf1 = buf2;
          skip = false;
          continue;
         }
       if(isupper(buf1))
         { // Главна буква
          if(isupper(buf2)|| isdigit(buf2) || buf2 == '#')
            { // Следва главна буква или цифра или край на символния низ
              carType = 1; // Лека кола
             Sl++;        // Брояч
            }
          else
            {
              if(islower(buf2))
                { // Следва малка буква
                  carType = 2;  // Камион
                  Sh++;
                  skip = true;  // Вторият символ е малка буква - вече е обработен да премине на следващ
                }
            }
         }
        else
         {
          if(isdigit(buf1))
            { //Цифра
             if(isdigit(buf2))
               { // Втора цифра
                num = (buf1-'0')*10+(buf2-'0');
                skip = true; // Да прескочи на следващия символ - вече е обработена втората цифра
               }
             else
               { //Само една цифра
                num=buf1-'0';
               }
              if(carType == 1) Sl += num-1; // Брояч леки коли
              else             Sh += num-1; // Брояч камиони
             }
          }
        buf1 = buf2; // Символ напред
      }
   while(buf2 != '#'); // Дали е достигнат край на символния низ?
   cout <<Sl<<" "<<Sh<<endl; // Печат краен резултат
   return 0;
}
/* Край на програмата */
