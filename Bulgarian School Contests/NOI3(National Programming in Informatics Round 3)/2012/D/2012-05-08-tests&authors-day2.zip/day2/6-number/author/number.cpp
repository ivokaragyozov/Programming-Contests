//Task: number
//Author: Kinka Kirilova-Lupanova

#include <iostream>
#include <string>
using namespace std;

bool good[37];
string convert(int n,int k)
{int i,l,c;
 char digit;
 string result="";
 while (n>0)
       {c=n%k;
        if (c<10) digit=char(int('0')+c);
        else digit=char(int('a')+c-10);
        n=n/k;
        result=digit+result;
       }
 return result;
}

bool isPalindrome(string s)
{int i,l;
 bool result=true; 
 l=s.length();
 for (i=0;i<l;i++) 
     if (s[i]!=s[l-1-i]) result=false;
 return result;
}
 
  int main()
{int i,cnt=0,n;
 cin>>n;
 for (i=2; i<37; i++)
      good[i]=isPalindrome(convert(n,i));
 for (i=2; i<37; i++)
     if (good[i]) cnt++;
 if (cnt==0) cout<<"none";
 else 
      if (cnt==1) cout<<"unique\n";
      else cout<<"multiple\n";
 for (i=2; i<37; i++)
     if(good[i]) cout<<i<<" ";
 cout<<endl;
}  

    
