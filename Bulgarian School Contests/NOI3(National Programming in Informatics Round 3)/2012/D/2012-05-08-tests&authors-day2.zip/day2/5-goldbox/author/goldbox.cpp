// Task - goldbox
//Author - Plamenka Hristova
#include <iostream>
#define MAXROWS 100
#define MAXCOLS 150
#define MAXRECS 50

using namespace std;

int main()
{
    int a[MAXROWS][MAXCOLS];
    int rect[MAXRECS][4];
    int L, W, N, i, j, indk;
    long long G,S;
    cin >>L>>W>>N>>G;
    for(i=0; i<W; i++)
       {
        for(j=0; j<L; j++)
           cin >> a[i][j];
       }

    for(i=0; i<N; i++)
       {
        rect[i][0] = rect[i][2] = MAXCOLS;
        rect[i][1] = rect[i][3] = 0;
       }

     for(i=0; i<W; i++)
       for(j=0; j<L; j++)
          {
           if(a[i][j])
             {
              indk=a[i][j]-1;
              if(i<rect[indk][0])rect[indk][0]=i;
              if(i>rect[indk][1])rect[indk][1]=i;
              if(j<rect[indk][2])rect[indk][2]=j;
              if(j>rect[indk][3])rect[indk][3]=j;
             }
          }
     S=0;
    for(i=0; i<N; i++)
           S+=(rect[i][1]-rect[i][0]+1)*(rect[i][3]-rect[i][2]+1);
    cout<<S*G<<endl;
    return 0;
}
