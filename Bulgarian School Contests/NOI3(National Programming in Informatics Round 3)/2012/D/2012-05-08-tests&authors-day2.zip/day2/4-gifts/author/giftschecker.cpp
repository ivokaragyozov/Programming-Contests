#include<fstream>
#include<iostream>
#include<string>
using namespace std;

int main(int argc, char * argv[])
{   ifstream in,sol,out;
    string giftsOut,giftsSol;
    int n,i;
    int c1[31],c2[31],c3[31];
    int u1,u2,u3;
    int r[31];
    int p;
    bool fl;
    in.open(argv[1]);
    sol.open(argv[3]);
    out.open(argv[2]);

    if (in==NULL)
    {   printf("0\nCannot open in file\n");
        return 1;
    }
    if (out==NULL)
    {   printf("0\nCannot open out file\n");
        return 1;
    }
    if (sol==NULL)
    {   printf("0\nCannot open sol file\n");
        return 1;
    }


    in >> n;
    for (i=1;i<=n;i++)
      in >> r[i];
    out >> giftsOut;
    sol >> giftsSol;
//    cout << n << endl;
//    for (i=1;i<=n;i++)
//      cout << r[i] << " ";
//    cout << endl;
//    cout << giftsOut << endl;
//    cout << giftsSol << endl;
    for (i=1;i<=n;i++)
      c1[i]=i;
    u1=n;
    u2=n+1;
    u3=0;
    for (i=0;i<giftsOut.length();i++)
      if ((giftsOut[i]-'0')==1)
      {
         u2--;
         c2[u2]=c1[u1];
         u1--;
      }
      else
        if ((giftsOut[i]-'0')==2)
        {
          u3++;
          c3[u3]=c2[u2];
          u2++;
        }
        else
        {
          u1++;
          c1[u1]=c2[u2];
          u2++;
        }
    fl=false;
    if (u3!=n)
      fl=true;
    if (!fl)
      for (i=1;((i<=n) && (!fl));i++)
        if (c3[i] != r[i]) fl=true;
    p=0;
    if (!fl)
    {
      if (giftsSol.length()<giftsOut.length())
        p=3;
      else
        p=5;
    }
    if (p==(int)5)
      printf("%i\nAccepted\n", p);
    else
      if ((p>0) && (p<5))
        printf("%i\nPartially Accepted\n", p);
      else
        printf("%i\nWrong answer\n", p);
            return 0;
}
