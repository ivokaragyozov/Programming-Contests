//Task: crossword
//Author: Rusko Shikov
#include <iostream>
using namespace std;

const int mmax=21;
const int nmax=21;
int cr[mmax+2][nmax+2];

int m,n,k,r,c;

void input()
{
  int i,j;
  cin >> m >> n;
  for (i=1;i<=m;i++)
    cr[i][0]=cr[i][n+1]=-1;
  for (j=1;j<=n;j++)  
    cr[0][j]=cr[m+1][j]=-1;
  for (i=1;i<=m;i++)
    for (j=1;j<=n;j++)
      cin >> cr[i][j];
  cin >> k;
  cin >> r >> c;
}

int main()
{
  int nw=0;         // ��� �� �� �������� ��������� ����� �� ����  
  int ch=0,cv=0;
  int dkh=0,dkv=0;
  int nrch=0,nrcv=0;
  int i,j,p,x;
  input();
  
  for (i=1;i<=m;i++)
    for (j=1;j<=n;j++)  
      if ((cr[i][j]==0) && (((cr[i-1][j]==-1)&&(cr[i+1][j]==0)) || ((cr[i][j-1]==-1) && (cr[i][j+1]==0))))
      {
        nw++;
        if ((cr[i-1][j]==-1)&&(cr[i+1][j]==0))
        {
          cv++;
          p=i;
          x=0;
          while (cr[p][j]==0)  
          {
            x++;
            if ((p==r)&&(j==c)) 
              nrcv=nw;
            p++;   
          }
          if (nw==k) dkv=x;
        }
        if ((cr[i][j-1]==-1) && (cr[i][j+1]==0)) 
        {
           ch++;           
           p=j;
           x=0;
           while (cr[i][p]==0)
           {
             x++;
             if ((i==r) && (p==c))
               nrch=nw;
             p++;   
           }
           if (nw==k) dkh=x;
        }
      }  
  cout << ch << " " << cv << endl; 
  cout << dkh << " " << dkv << endl; 
  cout << nrch << " " << nrcv << endl;     
  return 0;  
}