#include<fstream>
#include<iostream>
using namespace std;

int main(int argc, char * argv[])
{   ifstream sol,out;
    int hwo,vwo;
    int khwo,kvwo;
    int rchwo,rcvwo;
    int hws,vws;
    int khws,kvws;
    int rchws,rcvws;
    int p;

    sol.open(argv[3]);
    out.open(argv[2]);

    if (out==NULL)
    {   printf("0\nCannot open out file\n");
        return 1;
    }
    if (sol==NULL)
    {   printf("0\nCannot open sol file\n");
        return 1;
    }

    p = 0;

    out >> hwo >> vwo >> khwo >> kvwo >> rchwo >> rcvwo;
    sol >> hws >> vws >> khws >> kvws >> rchws >> rcvws;

    if ((hwo==hws) && (vwo==vws)) p = p+1;
    if ((khwo==khws) && (kvwo==kvws)) p = p+2;
    if ((rchwo==rchws) && (rcvwo==rcvws)) p = p+2;


    if (p==(int)5)
      printf("%i\nAccepted\n", p);
    else
      if ((p>0) && (p<5))
        printf("%i\nPartially Accepted\n", p);
      else
        printf("%i\nWrong answer\n", p);
            return 0;
}
