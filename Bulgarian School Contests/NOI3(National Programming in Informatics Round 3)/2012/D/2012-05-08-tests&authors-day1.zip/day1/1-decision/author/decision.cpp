//Task: decision
//Author: Kinka Kirilova-Lupanova

#include <iostream>
using namespace std;

int main()
{int   x,y,n,m,k,i,j,s,s1,i1,j1,t;
 cin>>x>>y>>n>>m>>k;
 s=x*k+y*k; 
 i=0;
  do
      {if (i==0) j=1;
       else j=0;
       t=0;
       do 
          {s1=x*i+y*j; 
           t=i*n+j*m; 
           if (s1<s && t>=k) 
                {s=s1; i1=i; j1=j;}
           j++; 
          }  
        while (t<k);
        i++;
       }
  while (i<=k/n+1);
 cout<<i1<<" "<<j1<<endl;
}  
