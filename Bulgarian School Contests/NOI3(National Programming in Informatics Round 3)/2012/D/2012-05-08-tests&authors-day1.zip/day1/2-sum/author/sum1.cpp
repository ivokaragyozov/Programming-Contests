/**
PROGRAM NAME: sum
AUTHOR: Evgenii Vassilev
*/
#include <iostream>
using namespace std;

int main(){
  unsigned long long a, b, p, q, s, i;
  cin >> a >> b >> p >> q;
  if (p<q) {p+=q; q=p-q; p-=q;}
  for (i=p; p%q; p+=i);
  if (i=a%p) a+=p-i;
  b-=b%p;
  for (s=0;a<=b;a+=p) s+=a;
  cout<<s<<endl;
  return 0;
}
