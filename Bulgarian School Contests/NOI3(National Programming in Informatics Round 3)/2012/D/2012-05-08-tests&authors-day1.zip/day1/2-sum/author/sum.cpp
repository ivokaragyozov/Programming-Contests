/**
PROGRAM NAME: sum
AUTHOR: Evgenii Vassilev
*/
#include <iostream>
using namespace std;

int main(){
  unsigned long long a, b, p, q, i;
  cin >> a >> b >> p >> q;
  for(i=(q>p?(p+=q,q=p-q,p-=q):p);p%q;p+=i); //LCM(p,q) -> p
  cout<<((b-=b%p)<((i=a%p)?a+=p-i:a)?0:((i=(b-a)/p+1),(a+=b),(a&1?i/2*a:a/2*i)))<<'\n';
  return 0;
}
