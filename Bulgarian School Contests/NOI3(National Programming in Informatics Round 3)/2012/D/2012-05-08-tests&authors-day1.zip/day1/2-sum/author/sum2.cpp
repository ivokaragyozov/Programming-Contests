/**
PROGRAM NAME: sum
AUTHOR: Rusko Shikov
*/

#include <iostream>

using namespace std;

unsigned long long p,q,a,b,lcm,sum1=0,lo,hi,n;

int main()
{
  cin >> a >> b >> p >> q;
  
  if (p<q) swap(p,q);
  lcm=p;
  while ((lcm % q) > 0)
    lcm=lcm+p;
  if ((a % lcm)==0)
    lo=a;
  else
    lo=a+(lcm-(a%lcm));
  hi=b-(b%lcm);
  for (n=lo;n<=hi;n=n+lcm)
    sum1=sum1+n;
  cout << sum1 << endl;
  return 0;         
}
