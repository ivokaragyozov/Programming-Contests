#include <iostream>
using namespace std;
int main()
{long long a,b;
 int c=0,d,s1,s2;
 long long t,i;
 cin>>a>>b;
 if (a%9!=0) a=9*(a/9+1);
 for (i=a;i<=b;i=i+9)
 {t=i;
  s1=s2=0;
  while (t!=0)
  {s1=s1+t%10;
   t=t/10;
  }
  t=9*i;
  while (t!=0)
  {s2=s2+t%10;
   if (s2>s1) break;
   t=t/10;
  }
  if (s1==s2) c++;
 }
 cout<<c<<endl;
}
