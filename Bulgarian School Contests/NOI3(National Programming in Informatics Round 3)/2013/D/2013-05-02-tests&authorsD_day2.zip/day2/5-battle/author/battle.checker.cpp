#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>


using namespace std;


int main(int argc, char *argv[]) {
    FILE *win;
    FILE *wout;
    FILE *wsol;
    int contx, conty, autx, auty, p;

    win = fopen(argv[1], "r");
    wout = fopen(argv[2], "r");
    wsol = fopen(argv[3], "r");

    if(wout == NULL) {
            printf("0\nCannot open out file\n");
            return 0;
            }

    fscanf(wout, "%d %d", &contx, &conty);
    fscanf(wsol, "%d %d", &autx, &auty);



    p = 0;
    if (((autx == contx) && (auty == conty)) || ((autx == conty) && (auty == contx)) )
      p = 4;
    else
      if ((autx == conty) || (autx == contx) || (auty == contx) || (auty == conty))
        p = 2;
      else
        p = 0;

    if(p==4)
       printf("%d\nAccepted\n", p);
    else
      if (p==2)
        printf("%d\nPartially Accepted\n", p);
      else
         printf("0\nWrong answer\n");
    return 0;
    }
