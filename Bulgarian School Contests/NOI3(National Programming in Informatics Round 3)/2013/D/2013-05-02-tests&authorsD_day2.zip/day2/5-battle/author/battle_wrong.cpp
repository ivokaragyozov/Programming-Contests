#include<iostream>
#include<vector>
#include<cstdio>
using namespace std;
struct TKw {
 int hor,ver,st;
};

int bR,bS,dK,NomT;
TKw a[1002][1002];
int brH,brV;

void Resh () {
int i,j;

    brH=0; brV=0;
    for (i=1;i<=bR+1;i++)
     for (j=1;j<=bS+1;j++)
      if (a[i][j].st<0) {
        if (a[i][j-1].hor+1-dK>0)
         brH=brH+a[i][j-1].hor+1-dK;
        if (a[i-1][j].ver+1-dK>0)
         brV=brV+a[i-1][j].ver+1-dK;
        a[i][j].hor=0; a[i][j].ver=0;
       }
       else {
        a[i][j].hor=a[i][j-1].hor+1;
        a[i][j].ver=a[i-1][j].ver+1;
       }
}

int main() {
int i,j,k,i1,j1;

	cin>>bR>>bS;
	cin>>dK;
	for (i=1;i<=bR;i++)
		for (j=1;j<=bS;j++) {
		scanf("%d",&k);
    if (k==1) {
     for (i1=i-1;i1<=i+1;i1++)
      for (j1=j-1;j1<=j+1;j1++)
       a[i1][j1].st=-2;
     a[i][j].st=-1;
    }

	}
  for (i=0;i<=bS+1;i++) {
    a[0][i].st=-1;
    a[bR+1][i].st=-1;
  }
  for (i=0;i<=bR+1;i++) {
    a[i][0].st=-1;
    a[i][bS+1].st=-1;
  }

	Resh();

	cout<<brH<<" "<<65<<endl;

  return 0;
}
/*
5 6
2
1 0 0 0 0 0
1 0 0 0 0 0
1 0 0 0 0 0
0 0 0 0 1 1
0 0 0 0 0 0


*/
