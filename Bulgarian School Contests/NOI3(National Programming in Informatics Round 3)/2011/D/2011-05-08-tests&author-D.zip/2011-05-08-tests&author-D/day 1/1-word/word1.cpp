//Task: word
//Author: Maria Eneva
#include<iostream>
#include<string>
#include<cctype>
using namespace std;

int find_word(int i)
{

}
bool correct(string c)
{
    if(c.length()%2==0)return 0;
    for(int j=0; j<c.length(); j++)c[j]=tolower(c[j]);
    bool f=true;
    for(int i=1; i<c.length(); i++)
      if((c[i]-'0')<(c[i-1]-'0')){ f=false; break; }
    return f;
}
int main()
{
    string s,s1="";
    int i, res_num=0, res_len=0, br=0;
    cin >> s;
    s=s+'*';

    s1="";
    for (i=0;i<s.length();i++)
      if (s[i]=='*')
        {
          if (s1.length()>0)
          {
            br++;
            if (correct(s1) && (s1.length()>res_len))
            {
              res_num=br;
              res_len=s1.length();
            }
          };
          s1="";
        }
      else
        if (((s[i]>='a') && (s[i]<='z')) ||  ((s[i]>='A') && (s[i]<='Z')) )
          s1=s1+s[i];


    cout << res_num << " " << res_len << endl;

    return 0;
}
