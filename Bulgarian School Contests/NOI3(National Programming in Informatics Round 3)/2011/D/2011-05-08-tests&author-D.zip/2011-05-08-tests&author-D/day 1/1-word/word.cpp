//Task: word
//Author: Maria Eneva
#include<iostream>
#include<string>
#include<cctype>
using namespace std;
bool correct(string c)
{
    if(c.length()%2==0)return 0;
    for(int j=0; j<c.length(); j++)c[j]=tolower(c[j]);
    bool f=1;
    for(int i=1; i<c.length(); i++)if(!(c[i]-'0'>=c[i-1]-'0')){ f=0; break; }
    return f;
}
int main()
{
    string s;
    getline(cin, s);
    for(int i=0; i<s.length(); i++)if(s[i]=='*')s.replace(i, 1, " ");

    int i=0;
    while (i<s.length())
      if(s[i]=='%' || s[i]=='=' || s[i]=='+' || s[i]=='-' || s[i]=='(' || s[i]==')' || s[i]==':' || s[i]=='.' || s[i]==',')
        s.erase(i, 1);
      else
        i++;
    string a[128]={""};
    int br=0;
    for(int i=0; i<s.length(); i++){ if(s[i]==' ' && s[i-1]!=' ')br++; if(s[i]!=' ')a[br]+=s[i]; }
    int res_num=0, res_len=0;
    br++;
    for(int j=0; j<br; j++)
            if(correct(a[j]))
            if(a[j].length()>res_len){ res_len=a[j].length(); res_num=j+1; }
    cout<<res_num<<" "<<res_len<<endl;
    return 0;
}
