//Task: lottery_naive
//Author: Kinka Kirilova-lupanova

#include<iostream>
using namespace std;
int main()
{ int n,a[100000], k,p,q,br,i,j,ans=0;
  cin>>n>>k;
  for (i=0;i<n;i++) cin>>a[i];
  cin>>p>>q;
  for (i=p;i<=q;i++)
      {br=0;
       for (j=0;j<n;j++)
          if (i%a[j]==0) br++;
       if (br==k) ans++;
      } 
  cout<<ans<<endl;
}

  
