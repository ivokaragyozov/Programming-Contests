//Task: lottery
//Author: Kinka Kirilova-lupanova

#include<iostream>
using namespace std;
int b[100000];
int main()
{ int n,a[100000], k,p,q,i,j,ans=0;
  cin>>n>>k;
  for (i=0;i<n;i++) cin>>a[i];
  cin>>p>>q;
  for (i=0;i<n;i++)
      {
       int r=p;
       if (r%a[i]==0) r=r-a[i];
       r=r+a[i]-p%a[i];
       for (j=r;j<=q;j=j+a[i])
          b[j-p]++;
      } 
   for (j=0;j<q-p+1;j++)
          if (b[j]==k)  ans++;
   
  cout<<ans<<endl;
}

  
