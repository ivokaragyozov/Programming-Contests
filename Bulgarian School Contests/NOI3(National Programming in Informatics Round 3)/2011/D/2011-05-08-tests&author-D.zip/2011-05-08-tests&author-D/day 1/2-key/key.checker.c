#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

using namespace std;
char s[64],r[64];
int N,L,m;
int freadstr(FILE *f, char *b, int bsize)
{int i;
 *b=0;
 fgets(b,bsize,f);
 if (!*b) return 0;
 for (i=0;i<bsize&&b[i]&&b[i]!='\n';i++);
 b[i]=0;
 return 1;
}
int freadint(FILE *f, char *b, int bsize, int cnt, int ressize, void *res)
{union {char c;
	      short s;
        long l;} r;
 int i,p;
 char *e;
 *b=0;
 fgets(b,bsize,f);
 if (!*b) return 0;
 for (i=0;i<bsize&&b[i]&&b[i]!='\n';i++);
 b[i]=' ';
 b[i+1]=0;
 p=0;
 for (i=0;i<cnt;i++)
 {while (b[p]==' '||b[p]=='\t') p++;
  r.l=strtol(&b[p],&e,10);
  if (*e!=' ' && *e!='\t') return 0;
  switch (ressize)
  {case sizeof(char):((char *)res)[i]=r.c; break;
   case sizeof(short):((short *)res)[i]=r.s; break;
   case sizeof(long):((long *)res)[i]=r.l; break;
   default: return 0;
  }
  p=e-b+1;
 }
 return 1;
}

char * strrev(char * string) {
  int length = strlen(string);
  char * result = (char*)malloc(length+1);
  if( result != NULL ) {
    int i,j;
    result[length] = '\0';
    for ( i = length-1, j=0;   i >= 0;   i--, j++ )  result[j] = string[i];
  }
  strcpy(string,result);
  return string;
}

char *rev(char *s,int start,int end)
{start--;
 end--;
 char c=s[end+1];
 s[end+1]=0;
 strrev(&s[start]);
 s[end+1]=c;
 return s;
}
char *rol(char *s)
{int L=strlen(s);
 char c=*s;
 strcpy(s,&s[1]);
 s[L-1]=c;
 return s;
}
void bt(int lev,int pi, int pj)
{int i,j;
 if (lev>=m) return;
 if (!strcmp(s,r)){m=lev;return;}
 for (i=1;i<L;i++)
  for (j=i+1;j<=L;j++) if (i!=pi || j!=pj)
  {rev(s,i,j);
   bt(lev+1,i,j);
   rev(s,i,j);
  }
}
int main(int argc, char **argv)
{FILE *f;
 char buf[64],sc[64];
 short i,NC;
 short p[2],res;
// if (argc!=4)
// {printf("Argument error\n");
//  return 0;
// }
 if (!(f = fopen(argv[1], "r"))) // input file
 {printf("Cannot open input.\n");
  return 0;
 }
 if (!freadstr(f,s,sizeof(s)))
 {printf("Bad input line 1\n");
  fclose(f);
  return 0;
 }
 L=strlen(s);
 if (!freadint(f,buf,sizeof(buf),1,sizeof(short),&N))
 {printf("Bad input line 2\n");
  fclose(f);
  return 0;
 }
 fclose(f);
 if (!(f = fopen(argv[2], "r")))    // competitor file
 {printf("0\nCannot open result.\n");
  return 0;
 }
 if (!freadint(f,buf,sizeof(buf),1,sizeof(int),&NC))
 {printf("0\nWrong count.\n");
  fclose(f);
  return 0;
 }
 if (NC<0)
 {if (NC==-1) printf("0\nThere is a solution!\n");
  else printf("0\nWrong count.\n");
  fclose(f);
  return 0;
 }
 strcpy(sc,s);
 for (i=0;i<NC;i++)
 {if (!freadint(f,buf,sizeof(buf),2,sizeof(short),p))
  {printf("0\nWrong number in line #%d.\n",i+2);
   fclose(f);
   return 0;
  }
  if (p[0]>p[1] || p[0]<0 || p[1]<0 || p[0]>L || p[1]>L)
  {printf("0\nWrong number in line #%d.\n",i+2);
   fclose(f);
   return 0;
  }
  rev(sc,p[0],p[1]);
 }
 fclose(f);
 N%=L;
 strcpy(r,s);
 for (i=0;i<N;i++) rol(r);
 if (strcmp(sc,r))
 {printf("0\nIncorrect result: %s (should be %s)\n",sc,r);
  return 0;
 }
 res=5;
 m=3;
 bt(0,0,0);
 res+=(int)floor(5.0*(double)(m+1)/(NC+1)+0.5);
 printf("%d\nCorrect",res);
 if (res<10) printf(", but not optimal.");
 printf("\n");
 return 0;
}
