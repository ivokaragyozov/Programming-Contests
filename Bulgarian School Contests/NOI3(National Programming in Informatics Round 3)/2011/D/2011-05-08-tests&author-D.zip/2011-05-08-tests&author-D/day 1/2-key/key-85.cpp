//Task: word
//Author: Pavlin Peev
#include <iostream>
#include <cstring>
using namespace std;
int main()
{ char s[32];
  int N,L;
  cin>>s>>N;
  L=strlen(s);
  N%=L;
  cout<<3<<endl;
  cout<<1<<' '<<N<<endl;
  cout<<N+1<<' '<<L<<endl;
  cout<<1<<' '<<L<<endl;
  return 0;
}
