// Task: triangle
// Author: Mladen Manev

#include<iostream>
using namespace std;

int main()
{
  long long a, i, s, mins, sr, sum = 0;
  cin >> a;
  mins = a + 1;
  for(i = 2; i*i <= a; i++)
    if (a % i == 0)
    {
      s = i  + a/i;
      if (s < mins)
        mins = s;
    }
  sr = (mins - 1)/2;
  for (i = 1; i <= sr; i++)
    sum += i * (mins - i);
  sum *= 2;
  if (mins % 2 == 0) sum += i*i;
  cout << sum << endl;
  return 0;
}

