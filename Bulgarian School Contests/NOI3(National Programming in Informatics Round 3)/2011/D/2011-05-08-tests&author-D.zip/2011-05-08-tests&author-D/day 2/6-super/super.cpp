//Task: super
//Author: Plamenka Hristova

#include <iostream>
using namespace std;

bool numbers[10000001];

void eratosten(int m)
{
  int i,k;
  for (i=1;i<=m;i++)
    numbers[i]=true;
  numbers[1]=false;
  for (i=2;i<=m;i++)
    if (numbers[i])
    {
      k=2*i;
      while (k<=m)
      {
        numbers[k]=false;
        k=k+i;
      }
    }
}

int main()
{
  int a,b,c,i, count=0;
  bool fl;

  cin >> a >> b;
  eratosten(b);


  for(i=a;i<=b;i++)
  {
   if (numbers[i])
   {
     fl=true;c=i/10;
     while ((c>1) && fl)
       if (!numbers[c])
         fl=false;
       else
         c=c/10;
     if (fl)
     {
       cout << i << endl;
       count++;
     }
   }


  }
  if(count==0) cout<<"NO"<<endl;
  return 0;
}
