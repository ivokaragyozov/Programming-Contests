#include <iostream>
using namespace std;

bool check_prime(int p)
{
  bool fl;
  int i;

  fl=true;
  i=2;
  while ((i*i<=p) && fl)
  {
    if (p%i == 0) fl=false;
    else i++;
  }
  return fl;
}

bool check_super_prime(int q)
{
  bool fl;
  fl=true;
  while ((q>1) && fl)
    if (check_prime(q))
      q=q/10;
    else
      fl=false;
  return fl;
}

int main()
{
  int a,b,i;
  int count=0;
  cin >> a >> b;
  if (a==1) a=2;
  for (i=a;i<=b;i++)
    if (check_super_prime(i))
    {
      cout << i << endl;
      count++;
    }
  if (count == 0)
    cout << "NO" <<  endl;

  return 0;
}
