#include<iostream>
using namespace std;

const int N=10001;
const int M=10001;
int n;
int a[N];
int b[M];

int main()
{
  cin >> n;
  int m=0;
  for(int i=1;i<=n;i++) {cin >> a[i]; if(m<a[i])m=a[i];}

  for(int i=1;i<=n;i++) b[a[i]]=1;
  
  int c=0;
  for(int j=1;j<=m;j++) c += b[j];
  cout << c << endl;


}
