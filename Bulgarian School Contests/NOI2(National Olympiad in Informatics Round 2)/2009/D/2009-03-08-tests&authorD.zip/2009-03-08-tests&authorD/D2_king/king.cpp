#include<iostream>
using namespace std;

int n;
int a[1001];
int b[1001];

int main()
{
  cin >> n;
  n = (n-1)/2;
  for(int i=1;i<=n;i++) cin >> a[i];
  for(int i=1;i<=n;i++) cin >> b[i];
  
  int m=9999;
  for(int i=1;i<=n;i++)
  for(int j=1;j<=n;j++)
  {
    if(a[i]==b[j])
    if(i+j<m) m=i+j;
  }

  cout << m << endl;

}
