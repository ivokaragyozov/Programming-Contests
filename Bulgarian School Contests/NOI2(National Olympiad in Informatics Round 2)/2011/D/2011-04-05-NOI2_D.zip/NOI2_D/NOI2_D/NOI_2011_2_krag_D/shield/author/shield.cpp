//Task: shield
//Author: Kinka Kirilova-Lupanova

#include <iostream>
using namespace std;

int main()
{int n,i,m1,m2,a[100],b[100];
 cin>>n;
 for (i=0;i<n;i++) cin>>a[i];
 for (i=0;i<n;i++) cin>>b[i];
 m1=a[0]+b[0];
 m2=a[0]+b[n-1];
 for (i=1; i<n;i++) 
    { if (m1>a[i]+b[i]) m1=a[i]+b[i];
      if (m2>a[i]+b[n-i-1]) m2=a[i]+b[n-i-1];
    }
 if (m1>m2) cout<<m1<<endl;
 else cout<<m2<<endl;
}
 
  
