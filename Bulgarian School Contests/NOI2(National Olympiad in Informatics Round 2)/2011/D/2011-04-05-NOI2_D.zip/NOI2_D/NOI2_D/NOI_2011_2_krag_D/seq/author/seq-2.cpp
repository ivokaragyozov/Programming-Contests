//Task: seq
//Author: Donka Darakchieva

#include <iostream>
#include <vector>
using namespace std;

int main()
{ vector<double> a;

  double x;
  cin >> x;
  while(x>0)
  { a.push_back(x);
    cin >> x;
  }

  int n = a.size();
  int k=1, kmax=1;

  for(int i=1; i<n; i++)
    if(a[i-1]<=a[i])
    { k++;
      if(k>kmax) kmax=k;
    }
    else k=1;

  cout << kmax << endl;

  return 0;
}
