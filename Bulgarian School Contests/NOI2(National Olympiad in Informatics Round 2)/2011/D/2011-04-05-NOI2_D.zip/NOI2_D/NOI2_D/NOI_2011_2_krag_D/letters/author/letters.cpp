#include<iostream>
using namespace std;
int main()
{ string s[10001][5];
  int br1=0, br2=0, br3=0, br4=0, br=0;
  int n;
  char c;
  cin>>n;
  cin>>c;
  for(int i=0;i<n;i++)
   for(int j=0;j<4;j++)
    cin>>s[i][j];
    
    for(int i=0;i<n;i++)
    if(s[i][0][0]==c||s[i][0][0]==c-32) br1++;
    
    for(int i=0;i<n;i++)
    {int m=s[i][1].size();
      for(int j=0;j<m;j++)
      if(s[i][1][j]==c||s[i][1][j]==c-32) {br2++; break;}
   
      }
       
    for(int i=0;i<n;i++)
    {int m=s[i][2].size();
      for(int j=0;j<m;j++)
      if(s[i][2][j]==c||s[i][2][j]==c-32) {br++; if(br==2) br3++;}
      br=0;
      }
    
    for(int i=0;i<n;i++)
    {int m=s[i][3].size();
     if(s[i][3][m-1]==c||s[i][3][m-1]==c-32) br4++;
     }
     cout<<br1<<" "<<br2<<" "<<br3<<" "<<br4<<endl;
     }
