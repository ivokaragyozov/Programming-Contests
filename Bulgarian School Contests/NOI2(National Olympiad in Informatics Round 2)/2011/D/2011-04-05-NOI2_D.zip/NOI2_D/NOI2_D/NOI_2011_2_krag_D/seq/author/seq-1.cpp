//Task: seq
//Author: Donka Darakchieva

#include <iostream>
using namespace std;

int main()
{ int k=1, kmax=1;

  double x,y;
  cin >> x;
  cin >> y;
  while(y>0)
  { if(x<=y) k++;
    else
    { if(k>kmax) kmax = k;
      k=1;
    }
    x = y;
    cin >> y;
  }
  if(k>kmax) kmax = k;
  cout << kmax << endl;

  return 0;
}
