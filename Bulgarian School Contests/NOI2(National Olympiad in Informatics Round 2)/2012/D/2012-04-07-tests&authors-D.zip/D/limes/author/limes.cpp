//Task: limes
//Author: Kinka Kirilova-Lupanova

#include <iostream>
using namespace std;
int q[100][100];

int main() 
{	int n, m, x, y;
	cin>>n>>m>>x>>y; 
	for (int i=0; i<n; i++) 
		for (int j=0; j<m; j++) 
			if (i%2== 0) 
				q[i][j] = j + m * i;
            else  
		        q[i][j] = m * (i  + 1) - j - 1;
   	cout<<q[x - 1][y - 1]<<endl;
}
