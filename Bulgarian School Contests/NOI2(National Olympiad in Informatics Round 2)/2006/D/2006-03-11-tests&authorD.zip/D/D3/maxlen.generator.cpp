#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

int main()
{ string test[11] = {"00","01","02","03","04","05","06","07","08","09","10"};
  
  srand(77);
    
  ofstream fout;
  
  int x = 1;
    
  for(int t = 0; t <= 10; t++)
  { int n = 7*(t+1) + rand()%7;
    
    fout.open(("maxlen." + test[t] +".in").c_str());
  
    int x = 1 + rand()%4;
    for(int i=1; i<=n; i++)
    { if(rand()%7 < 3) x = 1 + rand()%4;
      fout << x << " ";
    }  
    fout << 0 << endl;
  
    fout.close();
  }
   
  return 0;       
}
        
