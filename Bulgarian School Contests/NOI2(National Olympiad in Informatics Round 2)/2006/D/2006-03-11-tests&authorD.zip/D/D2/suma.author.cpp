#include<iostream>
using namespace std;

int t[51][51];
int p[51][51];

int main()
{
  int m, n, k, i0, j0;
  cin >> m >> n;
  for(int i=1;i<=m;i++)
  for(int j=1;j<=n;j++)
   cin >> t[i][j];
  cin >> k;
  cin >> i0 >> j0;

  int i1=i0-k; if(i1<1) i1=1;
  int i2=i0+k; if(i2>m) i2=m;
  int j1=j0-k; if(j1<1) j1=1;
  int j2=j0+k; if(j2>n) j2=n;
  
  int s=0;
  for(int i=i1;i<=i2;i++)
  for(int j=j1;j<=j2;j++)
   s += t[i][j];
  
  cout << s << endl;
}

