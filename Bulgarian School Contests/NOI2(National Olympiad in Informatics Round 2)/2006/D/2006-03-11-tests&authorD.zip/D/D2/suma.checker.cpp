#include <cstdio>
#include <cstring>
#include <cstring>
using namespace std;

int main(int argc, char *argv[])
{
 FILE * fo;
 FILE * fa;
 char buf[110], ans[110], sol[110];
 if (argc != 4)
 {
  printf("argument error");
  return 0;
 }
 fo = fopen(argv[2], "r");	// competitor file
 if (fo == NULL)
 {
	printf("0\nCannot open result.\n");
	return 0;
 }
 fa = fopen(argv[3], "r");	//help file
 if (fa == NULL)
 {
  printf("0\n%s\n no sol_file\n", argv[3]);
  return 0;
 }
 fgets(sol,100, fa);

 if (fgets(ans,100,fo) > 0 && fscanf(fo,"%5s", buf) <= 0 && strcmp(ans,sol) == 0)
 {
  printf("10\n");
  printf("Correct solution.\n");
  fclose(fa);
  fclose(fo);
  return 0;
 }

 while((strlen(sol)>0)&&(sol[strlen(sol)-1]<=32)) sol[strlen(sol)-1]=0;
 if(ans[0] !=0)
 while((strlen(ans)>0)&&(ans[strlen(ans)-1]<=32)) ans[strlen(ans)-1]=0;
 
 if(strcmp(ans,sol) == 0)
 {
  printf("10\n");
  printf("Correct solution.\n");
  fclose(fa);
  fclose(fo);
  return 0;
 }

 printf("0\n");
 printf("Incorrect output.\n%s\n%s\n%s\n",sol, ans, buf);
 fclose(fa);
 fclose(fo);
 return 0;
}
