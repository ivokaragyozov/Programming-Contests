#include<iostream>
using namespace std;
int broi(long long a)
{ 
    int br=0;
    while(a!=0)
    {
               a=a/10;
               br++;
    }
    return br;
}

int main()
{
    long long f1=1, f2=1, f3;
    int n,br=2,k,i;
    cin>>n;
    if(n==1||n==2) cout<<1<<endl;
    else
    {
        while (n>br)
        {
              n=n-br;
              f3=f1+f2;
              f1=f2;
              f2=f3;
              br=broi(f3);
        }
        k=br-n;
        for(i=0;i<k;i++)
        f3=f3/10;
        cout<<f3%10<<endl;
    }       
    return 0;
}
