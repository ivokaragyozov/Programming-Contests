#include <iostream.h>
#include <stdio.h>
#include <math.h>
int  main()
{long n, del[30]={0};
cin>>n;
long k=0,i=2,j=0,r=n;
while (n!=1)
 { while (n%i==0)
   {k+=i;del[j]=i;j++;n/=i;}
  i++;}
if (r<i) printf("No");
else {for (i=1;i<=r-k;i++)
       printf("%d ",1);
       for (i=0;i<j;i++)
       printf("%d ",del[i]);
     }
  printf("\n");
}
