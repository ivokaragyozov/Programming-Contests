#include <iostream>
using namespace std;
int main()
{int c=0,i,j,br=0,n,m;
 bool f;
 string s;
 cin>>n>>m;
 for (i=1;i<=n;i++)
     {cin>>s;
      f=true;
      for (j=0;j<m;j++)
          f=f && (s[j]=='*'); 
      if (f) c=c+1; 
      else 
           {br=br+c*(c+1)/2;
            c=0;
           } 
      }
 br=br+c*(c+1)/2;
 cout<<br<<endl;          
return 0;
}


