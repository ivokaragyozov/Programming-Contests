/**
TASK: tststsbreh
COMPETITION: Winter competitions in informatics, Veliko Tarnovo, 1-3 march, 2013
AUTHOR: Evgenii Vassilev
*/
#include <cstdio>
#include <cstring>
char A[1024], *p;
int n, st, cnv, i;
int main(){
  gets(A);
	sscanf(A,"%d", &n);
	for ( ; i<n ; i++){
	  gets(A);
	  for (cnv=0, p=A; *p != '.'; p++)
	    if (strchr(" aeiouy",*p)) cnv=0;
	    else if (++cnv > 3) {
	      st++;
	      break;
	    }
	}
  printf("%d %d\n", n-st, st);
	return 0;
}
