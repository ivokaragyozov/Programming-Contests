#include <iostream>
using namespace std;
int a[102][102][102];
int main()
{int w,h,l,k;
  cin>>w>>h>>l>>k;
  
  for(int i=1; i<=w;i++)
  for(int j=1;j<=h;j++)
 { a[i][j][1]++;
   a[i][j][l]++;}
  
  for(int i=1; i<=w;i++)
  for(int j=1; j<=l;j++)
 { a[i][1][j]++;
   a[i][h][j]++;}
  
  for(int i=1; i<=h;i++)
  for(int j=1;j<=l;j++)
  { a[1][i][j]++;
    a[w][i][j]++;}
        
int ans = 0 ;
  for(int i=1; i<=w;i++)
    for(int j=1;j<=h;j++)
       for(int p=1; p<=l;p++)
        if(a[i][j][p]==k) ans++;
        
        cout<<ans<<endl;
  }
  

