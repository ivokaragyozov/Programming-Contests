#include<iostream>
#include<stdlib.h>
using namespace std;
int main(){
long long len,i,ran;
cin>>len;
cout<<len<<"\n";
for(i=0;i<len;i++){
    ran=rand()%(len-1);
    if(ran<i){
        cout<<ran;
    }else{
        cout<<ran+1;
    }
    if(i<len-1){
        cout<<" ";
    }
}
cout<<"\n";
return 0;
}
