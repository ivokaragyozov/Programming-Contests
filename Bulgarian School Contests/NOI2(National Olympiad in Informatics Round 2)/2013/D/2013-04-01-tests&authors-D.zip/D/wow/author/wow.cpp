#include<iostream>
using namespace std;
int main(){
long long teleportirashtKum[10000],stupkaNaDostigane[10000], duljina,gledan,stignatiDosega=0;
cin>>duljina;
for(gledan=0;gledan<duljina;gledan++){
    cin>>teleportirashtKum[gledan];
    stupkaNaDostigane[gledan]=1000000;//znachi che ne e dostignat oshte!
}
gledan=0;
while(stupkaNaDostigane[gledan]==1000000){
    stupkaNaDostigane[gledan]=stignatiDosega;
    stignatiDosega++;
    gledan=teleportirashtKum[gledan];
}
cout<<stupkaNaDostigane[gledan]<<" "
    <<stignatiDosega-stupkaNaDostigane[gledan]<<" "
    <<duljina-stignatiDosega<<"\n";
return 0;
}
