//Task: weighing
//Author: Kinka Kirilova-Lupanova

#include <iostream>
using namespace std;
int l[128], r[128];

void weigh( char c, int a[], int size)
{int i;
 cout<<c<<':';
 for (i=0;i<size;i++)
   {if (i > 0) cout<<' ';
    cout<<a[i];
    }
  cout<<endl;
}

int main()
{int n, t=1, sameSize=0,otherSize=0;
 char c;
 cin>>c;
 cin>>n;
 while (n>0)
       {if (n%3==1) 
           {r[otherSize]=t;
            otherSize++;
            n=n - 1;
           }
        else 
            if (n%3==2)
               {l[sameSize]=t;
                sameSize++;
                n=n + 1;
               }
        n=n/3;
        t=t*3;
       }
    if (c=='L') 
       {weigh('L', l, sameSize);
        weigh('R', r, otherSize); 
       }  
    else    
       {weigh('L', r, otherSize);
        weigh('R', l, sameSize); 
       } 
  return 0;     
       
}
  

    
    

  
