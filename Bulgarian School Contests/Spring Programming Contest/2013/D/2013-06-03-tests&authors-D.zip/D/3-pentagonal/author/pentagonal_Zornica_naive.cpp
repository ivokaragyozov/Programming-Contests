#include <iostream>
using namespace std;
long long a[10000002];
long long k[1002];
int main()
{int n;
 a[1]=1; a[2]=5;
 for(int i=3;i<=100000005;i++)
 {a[i]=a[i-1]+(a[i-1]-a[i-2]+3);
 }
 cin>>n;
 for(int i=1;i<=n;i++)
 cin>>k[i];
 for(int i=1;i<=n;i++)
 cout<<a[k[i]]<<endl;
}
