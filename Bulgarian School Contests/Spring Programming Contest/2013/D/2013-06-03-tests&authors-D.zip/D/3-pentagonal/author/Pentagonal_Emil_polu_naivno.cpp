#include<iostream>
#include<algorithm>
using namespace std;

int n;
int k[1001], p[1001];
long long int b[1001];


int main()
{
  cin >> n;
  for(int i=1;i<=n;i++)
   { cin >> k[i]; p[i]=k[i];}
  sort(k, k+n+1);

  int m=k[n];
  long long int a=1;
  long long int s=0;
  int j=1;
  for(int i=1;i<=m;i++)
  {
    s +=a;
    a +=3;
    while(k[j]==i) {b[j]=s; j++;}
  }

  for(int i=1;i<=n;i++)
  {
    for(int j=1;j<=n;j++)
    if(p[i]==k[j]) {cout << b[j] << endl; break;}
  }

}
