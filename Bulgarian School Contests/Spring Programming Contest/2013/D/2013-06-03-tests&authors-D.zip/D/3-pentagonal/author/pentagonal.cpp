#include<iostream>
using namespace std;
long long broiTopkiTriugulnik(long long razmer){
    return razmer*(razmer+1)/2;
}
int main(){
long long broi, golemina;
for(cin>>broi;broi>1;broi--){
    cin>>golemina;
    cout<<broiTopkiTriugulnik(golemina*2-1)-broiTopkiTriugulnik(golemina-1)<<endl;
}
cin>>golemina;
cout<<broiTopkiTriugulnik(golemina*2-1)-broiTopkiTriugulnik(golemina-1)<<endl;
return 0;
}
