#include <iostream>
#define MAXN 1000001
using namespace std;
int cards[MAXN][2];
int path[MAXN],K;

void from_start()
{  path[1]=cards[0][0];
   for(int i=2;i<=K;i++)
   { if(cards[path[i-1]][0]!=path[i-2])
       path[i]=cards[path[i-1]][0];
     else
       if(cards[path[i-1]][1]!=-1)
          path[i]=cards[path[i-1]][1];
       else break;
    }
}

void from_end()
{  path[K-1]=cards[K][0];
   for(int i=K-2;i>=0;i--)
   { if(cards[path[i+1]][0]!=path[i+2])
       path[i]=cards[path[i+1]][0];
     else
       if(cards[path[i+1]][1]!=-1)
          path[i]=cards[path[i+1]][1];
       else break;
    }
}

int main()
{  int a,b,c,i;
   cin>>K;
   for(i=0;i<=K;i++)cards[i][0]=cards[i][1]=-1;
   for(i=1;i<K;i++)
   {  cin >> a>>b;
      if(cards[a][0]==-1) cards[a][0]=b;
      else cards[a][1]=b;
      if(cards[b][0]==-1) cards[b][0]=a;
      else cards[b][1]=a;
   }

   c=1;
   if(cards[0][0]==-1) c=0;
   else if(cards[K][0]==-1) c=2;
   path[0]=0;path[K]=K;
   if(c!=0) from_start();
   if(c!=2) from_end();
   for(int i=0;i<=K;i++)
      cout<<path[i]<<" ";
   cout<<endl;

}

