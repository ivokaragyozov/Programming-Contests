#include<fstream>
#include<iostream>
using namespace std;

int main(int argc, char * argv[])
{   ifstream sol,out;
    int t_out,t_sol;
    int ta_idle_out,ta_idle_sol;
    int tb_idle_out,tb_idle_sol;

    int p;

    sol.open(argv[3]);
    out.open(argv[2]);

    if (out==NULL)
    {   printf("0\nCannot open out file\n");
        return 1;
    }
    if (sol==NULL)
    {   printf("0\nCannot open sol file\n");
        return 1;
    }

    p = 0;

    out >> t_out >> ta_idle_out >> tb_idle_out;
    sol >> t_sol >> ta_idle_sol >> tb_idle_sol;

    if (t_out==t_sol) p = p+3;
    if (ta_idle_out==ta_idle_sol) p = p+1;
    if (tb_idle_out==tb_idle_sol) p = p+1;

    if (p==(int)5)
      printf("%i\nAccepted\n", p);
    else
      if ((p>0) && (p<5))
        printf("%i\nPartially Accepted\n", p);
      else
        printf("%i\nWrong answer\n", p);
            return 0;
}
