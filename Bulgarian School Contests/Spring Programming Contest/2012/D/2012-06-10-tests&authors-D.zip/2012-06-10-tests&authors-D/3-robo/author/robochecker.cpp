#include<fstream>
#include<iostream>
using namespace std;

int main(int argc, char * argv[])
{   ifstream sol,out;
    int xmsol,ymsol,brsol;
    int xmout,ymout,brout;
    char possol,posout;

    int p;

    sol.open(argv[3]);
    out.open(argv[2]);

    if (out==NULL)
    {   printf("0\nCannot open out file\n");
        return 1;
    }
    if (sol==NULL)
    {   printf("0\nCannot open sol file\n");
        return 1;
    }

    p = 0;

    out >> xmout >> ymout >> posout;
    out >> brout;
    sol >> xmsol >> ymsol >> possol;
    sol >> brsol;

    if ((xmout==xmsol) && (ymout==ymsol) && (posout==possol)) p = 1;
    if (brout==brsol) p = p+1;


    if (p==(int)2)
      printf("%i\nAccepted\n", p);
    else
      if ((p>0) && (p<2))
        printf("%i\nPartially Accepted\n", p);
      else
        printf("%i\nWrong answer\n", p);
            return 0;
}
