//Task: robo
//Author: Pavel Petrov
#include <iostream>
#include <algorithm>
#include<string>
using namespace std;

char Pos1,Pos2,Pos,Kom;
int d,i,kx,ky,X1,Y1,X2,Y2,X,Y,br;
string s;

void kXY () {
   if (Kom!='N') {
    kx= 0; ky= 0;
    if (Kom=='L') {
     switch (Pos) {
      case 'I': { Pos='S'; break;}
      case 'Z': { Pos='J'; break;}
      case 'S': { Pos='Z'; break;}
      case 'J': { Pos='I'; break;}
     }
    }
    else
    if (Kom=='D') {
     switch (Pos) {
      case 'I': { Pos='J'; break;}
      case 'Z': { Pos='S'; break;}
      case 'S': { Pos='I'; break;}
      case 'J': { Pos='Z'; break;}
     }
    }
    else
    if (Kom=='K') {
     switch (Pos) {
      case 'I': { Pos='Z'; break;}
      case 'Z': { Pos='I'; break;}
      case 'S': { Pos='J'; break;}
      case 'J': { Pos='S'; break;}
     }
    }
   }
   else {
    switch (Pos) {
     case 'I': { kx= 1; ky= 0; break;}
     case 'Z': { kx=-1; ky= 0; break;}
     case 'S': { kx= 0; ky= 1; break;}
     case 'J': { kx= 0; ky=-1; break;}
    }
   }
}

void Minimalni (){
// ����������
   br=Y2-Y1+X2-X1;
   if ((X1==X2)&&(Y2>Y1)) {
     if (Pos2=='S') {
       if (Pos1!='S') br=br+1;
     }
     else {
      if (Pos1=='S') br=br+1;
      else
      br=br+2;
     }
   }
   else
// ������������
   if ((X1!=X2)&&(Y2==Y1)) {
     if (Pos2=='I') {
       if (Pos1!='I') br=br+1;
     }
     else {
      if (Pos1=='I') br=br+1;
      else
      br=br+2;
     }
   }
// ������������
   else {
     if (Pos2=='I') {
       if (Pos1=='S') br=br+1;
       else
       br=br+2;
     }
     else
      if (Pos2=='S') {
       if (Pos1=='I') br=br+1;
       else
       br=br+2;
      }
      else {
       if (Pos1=='I'||Pos1=='S') br=br+2;
       else
       br=br+3;
      }
   }
}

int main () {
    cin>>Pos1;
    X=1; Y=1;
    Pos=Pos1; X1=X; Y1=Y;
    cin>>s;
    switch (Pos) {
     case 'I': { kx= 1; ky= 0; break;}
     case 'Z': { kx=-1; ky= 0; break;}
     case 'S': { kx= 0; ky= 1; break;}
     case 'J': { kx= 0; ky=-1; break;}
    }
    d=s.size();
    for (i=0;i<d;i++) {
     Kom=s[i];
     kXY();
     X=X+kx; Y=Y+ky;
    }
    X2=X; Y2=Y; Pos2=Pos;
    cout<<X2<<" "<<Y2<<" "<<Pos2<<endl;
    Minimalni();
    cout<<br<<endl;

	return 0;
}

/*
-------------------
������������
TEST 11
J
LNLNDNNNDNLNK
IZHOD:
6 1 Z
7
-------------------
������������
TEST 10
Z
KNLNDNNNDN
IZHOD:
5 1 J
6
-------------------
������������
TEST 9
S
DNLNDNNNDNL
iZHOD:
5 1 I
5
-------------------
������������
TEST 8
I
NLNDNNNDN
iZHOD:
5 1 J
5
-------------------
������������
TEST 7
I
NLNDNNNDNL
iZHOD:
5 1 I
4
-------------------
����������
TEST 6
J
KNDNLNNLNDNNNK
iZHOD:
1 7 J
8
-------------------
����������
TEST 5
I
LNDNLNNLNDNNNK
iZHOD:
1 7 J
8
-------------------
����������
TEST 4
Z
DNDNLNNLNDNNN
iZHOD:
1 7 S
7
-------------------
����������
TEST 3
Z
DNDNLNNLN
iZHOD:
1 4 Z
5
-------------------
����������
TEST 2
S
NDNLNNLNDNNN
iZHOD:
1 7 S
6
-------------------
����������
TEST 1
S
NDNLNNLN
iZHOD:
1 4 Z
4
-------------------
������������
TEST 0
S
NNDNNLNDNNNDN
IZHOD:
6 3
9
--------------------

I
LNNNDNNNDN
*/
