//Task: degree
//Author: Kinka Kirilova-Lupanova
#include <iostream>
using namespace std;

int main()
{int i,n,a[30],x;
 cin>>n;
 while (n>0)
        {n=n-1;
         int k=0;
         cin>>x;
         i=2;
         while (i*i<=x)
           if (x%i==0)
              {x=x/i;
               int br=1;
               while (x%i==0)  {br++;x=x/i;}
               a[k]=br;k++;
              }
            else i++;
         if (x>1) {a[k]=1;k++;}
         int min=a[0];
         for (i=1;i<k;i++)
              if (a[i]<min) min=a[i];
         if (min==1) cout<<"NO\n";
         else 
               {bool f=true;
                for (i=0;i<k;i++) f=f && (a[i]%min==0);
                if (f) cout<<"YES\n";
                else cout<<"NO\n";
               }
        }    
}
