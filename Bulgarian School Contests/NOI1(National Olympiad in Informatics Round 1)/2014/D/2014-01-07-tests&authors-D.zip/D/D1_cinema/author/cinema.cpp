#include<iostream>
using namespace std;

int N, M, a;

int main()
{
  cin >> N >> M >> a;
  int i = 1 + (a-1) / M;
  int j = 1 + (a-1) % M;
  
  cout << i << " " << j << endl;
}
