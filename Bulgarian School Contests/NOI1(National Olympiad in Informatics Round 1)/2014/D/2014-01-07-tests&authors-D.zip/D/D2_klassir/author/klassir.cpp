#include<iostream>
using namespace std;

struct s {int a; int t;};

const int N=1001;
s c[N];
int n;

bool cmp(s c1, s c2)
{
  if(c1.t > c2.t) return true;
  if(c1.t==c2.t)
  if(c1.a < c2.a) return true;
  return false;    
     
}

int main()
{
  n=4;
  for(int i=1;i<=n;i++) {cin >> c[i].a; c[i].t=c[i].a-i;}
  
  
//  for(int i=1;i<=n;i++)
//  cout << c[i].a << " " << c[i].t << endl;
//  cout << endl << endl;
   
  sort(c+1,c+n+1,cmp);

//for(int i=1;i<=n;i++)
//cout << c[i].a << " " << c[i].t << endl;
//cout << endl << endl;
  
  cout << c[1].a;
  for(int i=2;i<=n;i++) cout << " " << c[i].a;
  cout << endl;
   
}
