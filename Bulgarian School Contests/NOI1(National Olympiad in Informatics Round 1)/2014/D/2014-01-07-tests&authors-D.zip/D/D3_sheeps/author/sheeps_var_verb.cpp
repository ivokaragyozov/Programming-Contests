#include<iostream>
using namespace std;

long long int s, a0, a1, a2;
int t;
int k;


int main()
{
 cin >> k;
 s=1;
 t=0; a0=s; 
 cout << "t=" << t << " s=" << s << " a0=" << a0 << " a1=" << a1 << " a2=" << a2 << endl; 
 if(k==0) {cout << s+a2+a1+a0 << endl; return 0;}
 
 t=1; a1=a0; a0=s,
 cout << "t=" << t << " s=" << s << " a0=" << a0 << " a1=" << a1 << " a2=" << a2 << endl; 
 if(k==1) {cout << s+a2+a1+a0 << endl; return 0;}
 
 t=2; a2=a1; a1=a0; a0=s;
 cout << "t=" << t << " s=" << s << " a0=" << a0 << " a1=" << a1 << " a2=" << a2 << endl; 
 if(k==2) {cout << s+a2+a1+a0 << endl; return 0;}
 
 
 t=3; s += a2; a2=a1; a1=a0; a0=s; 
 cout << "t=" << t << " s=" << s << " a0=" << a0 << " a1=" << a1 << " a2=" << a2 << endl; 
 if(k==3) {cout << s+a2+a1+a0 << endl; return 0;}
 
 for(int t=4;t<=k;t++) 
 {s += a2; a2=a1; a1=a0; a0=s;
  cout << "t=" << t << " s=" << s << " a0=" << a0 << " a1=" << a1 << " a2=" << a2 << endl; } 
  
 cout << endl;
 cout << s+a2+a1+a0 << endl;
 
 system("pause");
    
}
