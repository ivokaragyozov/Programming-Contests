//Task:sheeps
//Author T.Teodosiev
#include <iostream>
using namespace std;
int main()
{unsigned long long k,s1=3,s2=4,s3=6,sk=s3;
cin>>k;
for (int j=4;j<=k;j++)
  { sk=s1+s3;
    s1=s2;s2=s3;s3=sk;
    }
        cout<<sk<<endl;
   }
