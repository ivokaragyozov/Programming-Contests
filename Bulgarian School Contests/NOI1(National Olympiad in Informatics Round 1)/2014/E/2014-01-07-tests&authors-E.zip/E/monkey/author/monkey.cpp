//Task: monkey
//Author: Suzan Feimova
#include<iostream>
using namespace std;
int main()

{  int D, M, G, N, K, X, P, D1, M1, G1, P1;
   cin>>D>>M>>G>>N>>K>>X;
  
   if((N-K)%(K-X)==0)
     P1=(N-K)/(K-X);
     else 
       P1=(N-K)/(K-X)+1;
   
   D=D+P1;
   
   if(M==2)
     {
      if(((G%4==0)&& (G%100!=0))||(G%400==0)) P=29;
        else P=28;
     }
     else
       {
        if((M==4)||(M==6)||(M==9)||(M==11)) P=30;
          else P=31;
       }
           
  if(D>P)
    {   
     D1=D-P;
     if(M<12) {M1=M+1; G1=G;}
       else {M1=1; G1=G+1;} 
    }
    else 
      {D1=D; M1=M; G1=G;}
    
  cout<<D1<<" "<<M1<<" "<<G1<<endl;
  
  return 0;
}
