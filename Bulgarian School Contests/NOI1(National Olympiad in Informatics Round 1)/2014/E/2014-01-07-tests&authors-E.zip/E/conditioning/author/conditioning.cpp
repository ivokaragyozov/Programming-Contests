//Task: conditioning
//Author: Kinka Kirilova-Lupanova

#include <iostream>
using namespace std;

int main()
{
    int troom, tcond;
    char s;
    cin >> troom >> tcond;
    cin >> s;
    if (s == 'v') cout << troom;
    if (s == 'a') cout << tcond;
    if (s == 'f') if (troom > tcond) cout<<tcond;
                  else cout<<troom;
    if (s == 'h') if (troom < tcond) cout<<tcond;
                  else cout<<troom;
    cout << endl;
    return 0;
}  


  
