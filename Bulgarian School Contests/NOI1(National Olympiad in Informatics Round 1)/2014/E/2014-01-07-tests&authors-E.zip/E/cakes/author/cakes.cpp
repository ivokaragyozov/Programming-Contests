//Task: cakes
//Author: Zornitca Dzhenkova

#include <iostream>
using namespace std;
int main()
{ int t1,t2,t3,d1,d2,d3,mint,mind,maxt,maxd;
  cin>>t1>>d1>>t2>>d2>>t3>>d3;
    
  maxt=0; mint=20001;
  maxd=0; mind=101;
  if(t1>maxt) maxt=t1;
  if(t2>maxt) maxt=t2;
  if(t3>maxt) maxt=t3;
 
  if(t1<mint) mint=t1;
  if(t2<mint) mint=t2;
  if(t3<mint) mint=t3;
  
  if(d1>maxd) maxd=d1;
  if(d2>maxd) maxd=d2;
  if(d3>maxd) maxd=d3;
  
  if(d1<mind) mind=d1;
  if(d2<mind) mind=d2;
  if(d3<mind) mind=d3;

  bool b1 = 1, b2 = 1, b3 = 1;
 
  
  if(maxt==t1&&maxd==d1) {cout<<1<<" "; b1=0;}
  if(maxt==t2&&maxd==d2) {cout<<2<<" "; b2=0;}
  if(maxt==t3&&maxd==d3) {cout<<3<<" "; b3=0;}
  
  if(mint==t1&&mind==d1) if(b2==0)cout<<3<<" "<<1<<endl;  else cout<<2<<" "<<1<<endl;
  if(mint==t2&&mind==d2) if(b1==0) cout<<3<<" "<<2<<endl; else cout<<1<<" "<<2<<endl;
  if(mint==t3&&mind==d3) if(b1==0)cout<<2<<" "<<3<<endl; else cout<<1<<" "<<3<<endl;
  return 0;
}
